<template>
  <el-container>
    <el-header style="height: 100px">上海海洋大学
      <el-button type="primary" @click="button">主要按钮</el-button>
    </el-header>
    <el-container>
      <el-main >
        <div class="block">
          <div></div>
          <div><span class="demonstration">默认</span></div>
          <el-image :src="src">
            <div slot="error" class="image-slot">
              <i class="el-icon-picture-outline"></i>
            </div>
          </el-image>
        </div>
        <el-upload
          class="upload-demo"
          action="1"
          :http-request="uploadFile"
          :on-preview="handlePreview"
          :on-remove="handleRemove"
          :before-remove="beforeRemove"
          multiple
          :limit="1"
          :on-exceed="handleExceed"
          :file-list="fileList">
          <el-button size="small" type="primary">点击上传</el-button>
          <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
        </el-upload>
      </el-main>
      <el-main>
        <div class="block">
          <div><span class="demonstration">自定义</span></div>
          <el-image :src="src">
            <div slot="error" class="image-slot">
              <i class="el-icon-picture-outline"></i>
            </div>
          </el-image>
        </div>
      </el-main>
    </el-container>
  </el-container>

</template>

<script>
import jpg from '@/assets/picture1.png'
import axios from "axios";


export default {
  data() {
    return {
      picture1:jpg

    }
  },
  methods: {
    button(){
      axios.get('http://127.0.0.1:80/book')
        .then(function (response) {
          console.log(response);
        })
        .catch(function (error) {
          console.log(error);
        });
    },
    uploadFile(params) {
      console.log("uploadFile", params);

      const _file = params.file;
      // const isLt2M = _file.size / 1024 / 1024 < 2;

      // 通过 FormData 对象上传文件
      var formData = new FormData();
      formData.append("file", _file);

      // if (!isLt2M) {
      //   this.$message.error("请上传2M以下的.xlsx文件");
      //   return false;

      axios.get('http://127.0.0.1:80/book')
        .then(function (response) {
          console.log(response);
        })
        .catch(function (error) {
          console.log(error);
        });


      },



    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    handleExceed(files, fileList) {
      this.$message.warning(`当前限制选择 1 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${ file.name }？`);
    }

  }
}
</script>


<style>
/*.block{*/
/*  height: 500px;*/
/*  width: 750px;*/
/*}*/


.el-header, .el-footer {
  background-color: #B3C0D1;
  color: #333;
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #D3DCE6;
  color: #333;
  text-align: center;
  line-height: 60px;
}

.el-main {
  background-color: #E9EEF3;
  color: #333;
  height: 620px;
  text-align: center;
  line-height: 60px;
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
</style>
